/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.viva;
import java.util.Random;
/**
 *
 * @author user
 */
public class Pokémon {
    
    private String uniqueID,name,element;
    private int hit_point,attack,defense,speed,special,level;
    Random rand=new Random();

    public Pokémon(String uniqueID, String name, String element) {
        this.uniqueID = uniqueID;
        this.name = name;
        this.element = element;
        this.hit_point = getAttribute(1);
        this.attack = getAttribute(2);
        this.defense = getAttribute(3);
        this.speed = getAttribute(4);
        this.special = getAttribute(5);
        this.level = 0;
    }
   
    public int getAttribute(int a){
        switch (a) {
            case 1:
                return rand.nextInt(26-15)+15;
            case 2:
            case 3:
                return rand.nextInt(18-10)+10;
            case 4:
                return rand.nextInt(16-5)+5;
            default:
                return rand.nextInt(11-5)+5;
        }
    }
    
    public void increaseLevel(){
        this.level++;
        this.hit_point+=rand.nextInt(6-2)+2;
        this.defense+=rand.nextInt(4-1)+1;
        this.attack+=rand.nextInt(4-1)+1;
        this.special+=rand.nextInt(4-1)+1;
        this.speed+=rand.nextInt(4-1)+1;
    }
    
    @Override
    public String toString(){
        return this.name+" ("+this.uniqueID+") is at level "+this.level+"\n"+
               "Hit Point (HP): "+this.hit_point+"\n"+
                "Attack: "+this.attack+"\n"+
                "Defense: "+this.defense+"\n"+
                "Speed: "+this.speed+"\n"+
                "Special: "+this.special+"\n";
    }
}
