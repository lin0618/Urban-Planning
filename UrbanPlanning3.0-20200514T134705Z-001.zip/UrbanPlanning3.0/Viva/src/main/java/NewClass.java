
import com.mycompany.viva.Pokémon;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class NewClass {
    public static void main (String[]args){
        Pokémon p=new Pokémon("ndsjfjl","Yow","THUNDER");
        System.out.println(p.toString());
        p.increaseLevel();
        p.increaseLevel();
        p.increaseLevel();
        System.out.println(p.toString());
    }
}
